<?php

    $con = mysqli_connect('localhost','root','','Mystore');
    if($con){
        return $con;
    }
else{
    die(mysqli_error($con));
}
   

?>